# Framework repos
The directories listed display the directory structure for each repo and each are their own macro-repo.
