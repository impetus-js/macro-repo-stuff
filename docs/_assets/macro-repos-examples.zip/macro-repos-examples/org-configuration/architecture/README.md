# Architecture

Every document that defines the platform (architecture). These files can generate diagrams.

Also needed to run entire organization's platform locally.
