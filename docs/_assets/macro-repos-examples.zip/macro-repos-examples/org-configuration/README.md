# Organization Configurations
The repo that is used for setup of the organization's platform. Contains

1. Architecture definition
2. OPs configurations
3. Generator templates
4. Defaults overrides
5. Default packages
   1. Override the provided injectables
   2. Required packages available to everyone
   3. Generators
6. Codemods?
