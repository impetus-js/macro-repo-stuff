Packages to be shared across macro-repo packages.

Keeps the `packages` directory focused on just the business rules