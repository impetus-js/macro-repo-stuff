# Table Flip
Given that the company's main product is a SaaS ready banking platform it makes sense that the platform itself is it's own domain. In the future it may need to be broken down further (or after a DDD session) as the company expands but for now this is what makes the most sense.

The `_man` domain/repo is the platform codebase for the banking system. 
