exports = module.exports = {
  prop: 'value',
};
