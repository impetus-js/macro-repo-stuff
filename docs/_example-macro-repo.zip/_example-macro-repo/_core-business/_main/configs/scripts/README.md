Scripts that we use either locally or on the server. 

For instance we can run a backup every sunday night on a  `cron` job in case we screw up the database for some reason.
