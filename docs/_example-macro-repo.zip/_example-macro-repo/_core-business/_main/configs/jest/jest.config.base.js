module.exports = {
  roots: ['<rootDir>/src'],
  transform: {
    '^.+\\.tsx?$': 'ts-jest',
  },
  testRegex: '(/__tests__/.*|(\\.|/))\\.(test|spec)\\.tsx?$',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  collectCoverage: process.env.WATCHMODE ? false : true,
  collectCoverageFrom: ['src/**/*.ts'],
  coveragePathIgnorePatterns: [
    'src/index.ts',
    'src/config.ts',
    'src/documents/*.*',
    'src/routes/__tests__/queries.helper.ts',
    'src/queries/__tests__/test-helpers.ts',
    'src/queries/db-injector.ts',
    'src/services/IdentityCheckService.ts', //must be remove after we integrate with radmin.
    'src/queries/claimant-verification.ts', //must be remove after we integrate with radmin.
    'src/routes/', //must be remove after we integrate with radmin.
  ],
  moduleDirectories: ['node_modules', '.'],
  setupFiles: ['<rootDir>/jest.env.js'],
};
