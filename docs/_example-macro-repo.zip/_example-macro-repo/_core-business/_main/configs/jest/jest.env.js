process.env.ENV_TYPE = process.env.ENV_TYPE || 'test';
process.env.PGHOST = process.env.PGHOST || 'localhost';
process.env.PGPASSWORD = process.env.PGPASSWORD || 'db';
process.env.PGPORT = process.env.PGPORT || '31000';
process.env.PGUSER = process.env.PGUSER || 'db'
process.env.PGDATABASE = process.env.PGDATABASE || 'db'
