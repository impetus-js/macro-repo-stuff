const base = require('./jest.config.base.js');

module.exports = {
  ...base,
  coverageThreshold: {
    global: {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
    'src/controllers/': {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
    'src/documents': {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
    'src/emails': {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
    'src/queries': {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
    // 'src/services': {
    //   statements: 0,
    //   branches: 0,
    //   functions: 0,
    //   lines: 0,
    // },
    'src/templates': {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
  },
};
