# Tool configurations
Global configurations for this macrorepo.

Any configuration that is about tools that are used within this mono-repo.

This directory will NOT have any executable code.
