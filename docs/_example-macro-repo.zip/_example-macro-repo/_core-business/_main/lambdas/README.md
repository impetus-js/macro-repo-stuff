A directory of lambda functions if this is something we do in the future.

This folder should be lambdas, apis and graph ql stuff that is "global" to many other libraries.

What is contained within
  - Lambdas
  - A REST API 
  - Graph QL
  