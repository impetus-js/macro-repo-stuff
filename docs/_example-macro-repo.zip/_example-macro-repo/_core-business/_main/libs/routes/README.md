A library to generate URLs for a client or server.
