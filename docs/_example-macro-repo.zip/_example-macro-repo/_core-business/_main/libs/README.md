These are libraries ONLY for this repo and not shared outside of here. They _are technically_ publishable but only for the apps, services, lambdas within this repo should be using them. If repos outside of this repo could use any of the packages within this directory they should be moved to `kernal`. 

Consider this a "dumping ground" for a `library` until it's determined that this package is better off in the `kernel` macro-repo.
