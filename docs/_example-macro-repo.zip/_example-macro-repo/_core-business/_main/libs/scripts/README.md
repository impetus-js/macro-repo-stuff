Think of this like `react-scripts`

Start an app w/o having to set everything up manually.

Would handle webpack, building, 