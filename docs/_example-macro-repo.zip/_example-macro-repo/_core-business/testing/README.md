# Automated testing

These are packages that are used to test things automatically on the browser, lambdas etc.

The code that actually runs testing is within the packages themselves elsewhere.