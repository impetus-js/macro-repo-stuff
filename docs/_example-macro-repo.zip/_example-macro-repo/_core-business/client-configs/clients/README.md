Client configurations used for any given `app/*`

I feel like this should be it's own package in a different repo.