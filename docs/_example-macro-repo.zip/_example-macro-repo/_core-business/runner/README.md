The Runner repo is _ALL_ about code that runs code in a container of sorts.

The Runner is specifically for these types of sources.
1. A web app
2. A service

## Benefits
- Updates so 
- Everything should be auto loaded (server) or auto built so that there is no configuration is required to get started. Can write configurations if required.
- Updates should be significantly easier as the code runs inside of a container with a specific programming API.
- If the API changes for whatever reason it should be easy to run multiple versions.

## Drawbacks
- Gotta write it 😬

<!-- 

The Runner repo is a set of packages to handle
1. Bundler like `nx` or `webpack`
2. Runs code in a container (code, not actual VM)

-->