The Kernal macrorepo are shared libraries that would be shared across all non open-source packages.
