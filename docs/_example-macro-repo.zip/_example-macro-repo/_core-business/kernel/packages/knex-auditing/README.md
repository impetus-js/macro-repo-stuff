A library to add to any `Knex.QueryBuilder` object auditing functionality.

Can add & read any query & is fully functional so one can use it to pull in stuff.

Should be able to be a package and published but will keep in here for awhile.
