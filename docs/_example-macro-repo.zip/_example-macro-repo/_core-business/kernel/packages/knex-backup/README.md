A library to do backups on your knex managed database

## Features
### Tables
- Backup a table including it's keys & constraints
- Restore a table

### Table
- Backup an entire database
- Restore a database

## Notes
1. It expects a full Knex.js managed schema object in order to do it's work automatically.
1. Since `enum` modifications aren't supported in `knex`

------
## Useful Links
- [Copy Table](https://github.com/knex/knex/issues/1373)
- [Knex.js Migrations copy existing data to other table](https://stackoverflow.com/questions/45144377/knex-js-migrations-copy-existing-data-to-other-table)
- 
- 
- 
- 
- 
