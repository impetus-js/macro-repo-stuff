# Table Flip
Each one of these macrorepos are broken down by domain.

## Domain breakdown
Each directory in here is a macro-repo. A macro-repo is broken down by the domain that they encapsulate. Having one giant monorepo is not going to be benefical for us so this 

### Domain

### Repos
| Domain | Repo | Description |
| `Platform: Main` | `_main` | The entire SaaS system and is organized in a "clean architecture" pattern |
| `Client` | `client-configs` | All the client configs for all the clients that we'd have |
| `Infrastructure` | `infra` | All the infrastructure configurations plus packages that make working with all the kubernetes files much easier and faster |
| `Design` | `web` | Design system and components. These packages are to be extended elsewhere when required. |
| `Open Source` | `open-source` | The name explains it. |
| `Development: Testing` | `testing` | All the automated testing packages |
| `Development: Local` | `tools` | Developer tools such as CLI tools to work within the platform easier and generators to quickly scaffold code |
| `Development: Runtime` | `runner` | A suite of tools to run code w/o having to know the version one is on nor having to write coupious amount of code. |
| `Development: Core` | `kernel` | Shared libraries required for multiple packages |

## Frameworks
- Serverless
- Marble.js
- pnmp
- React (possibly)
- Scss
- Knex/Prisma
- ts-belt
- https://single-spa.js.org/

