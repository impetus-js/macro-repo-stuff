A package to make handling secrets easier. 

There needs to be a package for handling secrets in different platforms such as
- AWS
- Vault
- Etc
