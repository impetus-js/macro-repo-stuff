All the configurations will exist in each service/lambda etc. In order to keep things straight forward and easy the configurations are co-located with each package. 

What this package does is to allows easy generation of a CI/CD. Either pulling in the configurations from a package or using templates. Depends on the CI/CD platform being used so this isn't really useful just yet.
