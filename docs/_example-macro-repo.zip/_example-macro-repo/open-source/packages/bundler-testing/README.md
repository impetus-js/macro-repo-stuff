# Bundler Testing
Anything that is testing related is removed from the bundle. 

## Example

### Code
```tsx
export const FooComponent() => (
  <div id="foo-component" data-testid="Foo-Component-64788956">
  </div>
)
```

### Compiled Output
### Code
```tsx
export const FooComponent() => (
  <div id="foo-component">
  </div>
)
```