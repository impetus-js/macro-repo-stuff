# Bundler Logger
*NOTE*: This may be better as a `TypeScript`/`Babel` plugin instead.

Does two things
1. Appends logs to the codebase in the bundled output to make code easier and faster to write
2. Adds function, file and line number to all `console.log` code

## Example - Logger
Given the logger's signature looks like thus:
```js
logger(tag: string, functionName: string, data)
```

### Code
```js
export const foo = (params) => {
  logger[pre]: params
}
```

### Output
```js
import logger from '@tableflip/tools/logger'

export const foo = (params) => {
  logger('[PRE]', params)
}
```

### Benefits
The main benefit is that the logger can be
1. A single line and we don't need to worry about it
2. Faster to write
3. Doesn't pollute the codebase with a ton of logger code
4. Not required to write everything manually each time
  - Function name can change
  - Can use logger aliases: `loggerPre: params`
5. Also removes any `console.*` code from the build

## Example - Logger
### Code
```js
export const foo = (params) => {
  console.log('params', params)
}
```

### Output
```js
import logger from '@tableflip/tools/logger'

export const foo = (a, b, c) => {
  const bar = {
    some: 'object',
  }

  console.log('bar', bar, {
    file: './relative/path/to/file',
    func: `foo(${...arguments})`, // but, like, a correct way.
    line: 123,
  })
}
```

### Benefits