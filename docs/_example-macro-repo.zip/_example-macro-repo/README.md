# Table Flip Domains

## Overview
Domains, here, are macro-repos. Everything outside of `_core-business` should be updated sparingly unless there is a team that works on it like `tools`.

## Domains
| Domain | Reasoning | 
|:--|:--|
| `_core-business`| The core domain for the company. It is a SaaS codebase. Many of these | 
| `search`| Functionality relating to searching (if required) | 
| `uploads`| Essentially an adapter that allows us to control and better test upload functionality | 
| `logging`| The logging services and libraries for all domains | 
| `notifications`| Services & libraries | 
| `open-source`| Libraries that we've open sourced. If we decide one of our libraries is too good we'll open source it under the best GPL license | 
| `events`| Services & libraries | 
| `gateway`| Services & libraries | 
| `local-services`| Services, libraries & mocks needed to ease local development | 
| `documents`| Services to generate documents to be consumed and signed by other domains | 
| `communications`| Code & services for handling different types of communications like texting, phone calls,  emails etc | 

Every domain should be written with SaaS in mind and not on-prem deployables. If on-prem is required then we'll figure out how to build that out later.

## Technologies, patterns & paradigms
Technologies used at Table Flip that isn't what we've built.

| Technology | Pattern | Paradigm |
|:--|:--|:--|
| Parcel | | Functional programming |
| Node | | |
| TypeScript | | |
| React | | |
| eslint | | |
| fp-ts (potentially) | | |
| ts-belt | | |
| xstate | | |
| ts-pattern | | |
| rxjs | | |
| JSON 5 | | |
| YAML | | |
| [Micro Front Ends](https://single-spa.js.org/) |  |  |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |

## Sundries
**NOTES**
1. Some of these domains could move into `_core-business`. Like `uploads` but it all to be seen.
2. Every domain is in it's own `VPC` which means that each of these will need to handle their own infra and also means that they require a way to handle permissions so that other domains can access them. Sometimes we'll open them up to clients when the time comes.

<!--

app-builder. I'll need to figure this out later but we'll need to think about how we handle custom applications that clients will need. 

Options
- https://github.com/rjsf-team/react-jsonschema-form
- https://formkit.com/essentials/schema

-->